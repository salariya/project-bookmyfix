import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Clock, Shield, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const ServicePricing = () => {
  const { service } = useParams();
  const navigate = useNavigate();

  const servicePlans = {
    "plumbing": {
      title: "Plumbing Services",
      description: "Professional plumbing solutions for your home",
      plans: [
        {
          name: "Basic Repair",
          price: "₹299",
          duration: "1-2 hours",
          features: ["Minor leak fixes", "Tap repairs", "Basic consultations", "1 month warranty"]
        },
        {
          name: "Standard Service",
          price: "₹599",
          duration: "2-4 hours", 
          features: ["Pipe repairs", "Fixture installation", "Drain cleaning", "3 months warranty"],
          popular: true
        },
        {
          name: "Premium Package",
          price: "₹999",
          duration: "4-6 hours",
          features: ["Complete plumbing inspection", "Major repairs", "Multiple fixtures", "6 months warranty"]
        }
      ]
    },
    "electrician": {
      title: "Electrical Services",
      description: "Certified electrical solutions for safety and convenience",
      plans: [
        {
          name: "Basic Electrical",
          price: "₹399",
          duration: "1-2 hours",
          features: ["Switch/socket repair", "Basic wiring", "Safety check", "1 month warranty"]
        },
        {
          name: "Standard Service",
          price: "₹799",
          duration: "2-4 hours",
          features: ["Fan installation", "Light fixtures", "Circuit repairs", "3 months warranty"],
          popular: true
        },
        {
          name: "Premium Package",
          price: "₹1299",
          duration: "4-8 hours", 
          features: ["Complete rewiring", "Panel upgrades", "Smart home setup", "6 months warranty"]
        }
      ]
    },
    "home-cleaning": {
      title: "Home Cleaning Services",
      description: "Professional cleaning for a spotless home",
      plans: [
        {
          name: "Basic Cleaning",
          price: "₹499",
          duration: "2-3 hours",
          features: ["Room cleaning", "Dusting & mopping", "Bathroom cleaning", "Same day service"]
        },
        {
          name: "Deep Cleaning",
          price: "₹899",
          duration: "4-6 hours",
          features: ["Complete home deep clean", "Kitchen & appliances", "Windows & balcony", "Sanitization"],
          popular: true
        },
        {
          name: "Premium Package",
          price: "₹1499",
          duration: "6-8 hours",
          features: ["Sofa & carpet cleaning", "Disinfection service", "Organizing service", "Monthly package available"]
        }
      ]
    }
  };

  const currentService = servicePlans[service as keyof typeof servicePlans];

  if (!currentService) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Service Not Found</h1>
          <Button onClick={() => navigate('/')}>Return Home</Button>
        </div>
        <Footer />
      </div>
    );
  }

  const handleBookService = (plan: any) => {
    // Navigate to booking page with plan details
    navigate('/book-service', { state: { service: currentService.title, plan } });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-20">
        {/* Back button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="mb-8 hover:bg-accent"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Services
        </Button>

        {/* Service header */}
        <div className="text-center mb-12 animate-fade-in-up">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            {currentService.title}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {currentService.description}
          </p>
        </div>

        {/* Pricing plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {currentService.plans.map((plan, index) => (
            <Card 
              key={plan.name}
              className={`relative transition-all duration-300 hover:shadow-hover hover:-translate-y-2 animate-fade-in-up ${
                plan.popular ? 'border-primary shadow-glow scale-105' : 'border-border'
              }`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              
              <CardHeader className="text-center">
                <CardTitle className="text-xl font-bold text-foreground">
                  {plan.name}
                </CardTitle>
                <CardDescription className="text-3xl font-bold text-primary mt-2">
                  {plan.price}
                </CardDescription>
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{plan.duration}</span>
                </div>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-foreground">
                      <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-primary"></div>
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
              
              <CardFooter>
                <Button 
                  variant={plan.popular ? "default" : "outline"}
                  className="w-full"
                  onClick={() => handleBookService(plan)}
                >
                  Book Now
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Service guarantees */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-4xl mx-auto">
          <div className="text-center p-6 bg-card rounded-xl border border-border animate-fade-in-up">
            <Shield className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">100% Verified Professionals</h3>
            <p className="text-muted-foreground text-sm">All our service providers are background verified</p>
          </div>
          
          <div className="text-center p-6 bg-card rounded-xl border border-border animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <Star className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">Quality Guarantee</h3>
            <p className="text-muted-foreground text-sm">30-day service guarantee on all bookings</p>
          </div>
          
          <div className="text-center p-6 bg-card rounded-xl border border-border animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <Clock className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">On-Time Service</h3>
            <p className="text-muted-foreground text-sm">Punctual service delivery as promised</p>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default ServicePricing;