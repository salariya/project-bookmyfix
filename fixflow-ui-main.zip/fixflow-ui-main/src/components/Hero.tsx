import { Button } from "@/components/ui/button";
import heroIllustration from "@/assets/hero-illustration.jpg";
import LocationSelector from "./LocationSelector";

const Hero = () => {
  return (
    <section className="relative pt-20 pb-16 md:pt-28 md:pb-24 bg-gradient-hero overflow-hidden">
      <LocationSelector />
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          {/* Content */}
          <div className="flex-1 text-center lg:text-left animate-fade-in-up">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Your Fix,{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                Just a Tap Away
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto lg:mx-0">
              Book trusted electricians, plumbers, cleaners & more in seconds. 
              Professional service at your fingertips.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                variant="hero" 
                size="hero"
                className="animate-bounce-in"
                style={{ animationDelay: "0.3s" }}
              >
                Get the App
              </Button>
              <Button 
                variant="secondary" 
                size="lg"
                className="animate-bounce-in"
                style={{ animationDelay: "0.5s" }}
              >
                Learn More
              </Button>
            </div>
          </div>

          {/* Illustration */}
          <div className="flex-1 relative animate-scale-in" style={{ animationDelay: "0.2s" }}>
            <div className="relative">
              <img
                src={heroIllustration}
                alt="Home service professional with booking app"
                className="w-full max-w-lg mx-auto rounded-3xl shadow-medium animate-float"
              />
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-primary/10 rounded-full animate-glow"></div>
              <div className="absolute -bottom-6 -left-6 w-12 h-12 bg-primary-glow/20 rounded-full animate-float" style={{ animationDelay: "1s" }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -translate-y-32 translate-x-32"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary-glow/10 rounded-full translate-y-24 -translate-x-24"></div>
    </section>
  );
};

export default Hero;