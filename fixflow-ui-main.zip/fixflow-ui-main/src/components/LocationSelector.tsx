import { useState } from "react";
import { MapPin, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const LocationSelector = () => {
  const [selectedCity, setSelectedCity] = useState("");

  const indianCities = [
    // Tier 2 Cities
    { value: "agra", label: "Agra", tier: "Tier 2" },
    { value: "amritsar", label: "Amritsar", tier: "Tier 2" },
    { value: "bhopal", label: "Bhopal", tier: "Tier 2" },
    { value: "chandigarh", label: "Chandigarh", tier: "Tier 2" },
    { value: "coimbatore", label: "Coimbatore", tier: "Tier 2" },
    { value: "dehradun", label: "Dehradun", tier: "Tier 2" },
    { value: "guwahati", label: "Guwahati", tier: "Tier 2" },
    { value: "indore", label: "Indore", tier: "Tier 2" },
    { value: "jaipur", label: "Jaipur", tier: "Tier 2" },
    { value: "kochi", label: "Kochi", tier: "Tier 2" },
    { value: "lucknow", label: "Lucknow", tier: "Tier 2" },
    { value: "mangalore", label: "Mangalore", tier: "Tier 2" },
    { value: "mysore", label: "Mysore", tier: "Tier 2" },
    { value: "nagpur", label: "Nagpur", tier: "Tier 2" },
    { value: "patna", label: "Patna", tier: "Tier 2" },
    { value: "raipur", label: "Raipur", tier: "Tier 2" },
    { value: "ranchi", label: "Ranchi", tier: "Tier 2" },
    { value: "surat", label: "Surat", tier: "Tier 2" },
    { value: "thiruvananthapuram", label: "Thiruvananthapuram", tier: "Tier 2" },
    { value: "vadodara", label: "Vadodara", tier: "Tier 2" },
    { value: "visakhapatnam", label: "Visakhapatnam", tier: "Tier 2" },
    
    // Tier 3 Cities
    { value: "ajmer", label: "Ajmer", tier: "Tier 3" },
    { value: "aligarh", label: "Aligarh", tier: "Tier 3" },
    { value: "bikaner", label: "Bikaner", tier: "Tier 3" },
    { value: "durgapur", label: "Durgapur", tier: "Tier 3" },
    { value: "guntur", label: "Guntur", tier: "Tier 3" },
    { value: "hubli", label: "Hubli", tier: "Tier 3" },
    { value: "jammu", label: "Jammu", tier: "Tier 3" },
    { value: "jalandhar", label: "Jalandhar", tier: "Tier 3" },
    { value: "jodhpur", label: "Jodhpur", tier: "Tier 3" },
    { value: "kanpur", label: "Kanpur", tier: "Tier 3" },
    { value: "kota", label: "Kota", tier: "Tier 3" },
    { value: "madurai", label: "Madurai", tier: "Tier 3" },
    { value: "meerut", label: "Meerut", tier: "Tier 3" },
    { value: "moradabad", label: "Moradabad", tier: "Tier 3" },
    { value: "rourkela", label: "Rourkela", tier: "Tier 3" },
    { value: "saharanpur", label: "Saharanpur", tier: "Tier 3" },
    { value: "salem", label: "Salem", tier: "Tier 3" },
    { value: "shimla", label: "Shimla", tier: "Tier 3" },
    { value: "tirunelveli", label: "Tirunelveli", tier: "Tier 3" },
    { value: "warangal", label: "Warangal", tier: "Tier 3" }
  ];

  return (
    <div className="fixed top-20 right-4 z-40 bg-card/95 backdrop-blur-lg rounded-xl p-4 shadow-medium border border-border/50 animate-scale-in">
      <div className="flex items-center gap-2 mb-3">
        <MapPin className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium text-foreground">Select Your City</span>
      </div>
      
      <Select value={selectedCity} onValueChange={setSelectedCity}>
        <SelectTrigger className="w-48 bg-background border-border hover:border-primary transition-colors">
          <SelectValue placeholder="Choose your location" />
        </SelectTrigger>
        <SelectContent className="max-h-60">
          <div className="px-2 py-1 text-xs font-semibold text-muted-foreground">Tier 2 Cities</div>
          {indianCities.filter(city => city.tier === "Tier 2").map((city) => (
            <SelectItem key={city.value} value={city.value}>
              {city.label}
            </SelectItem>
          ))}
          <div className="px-2 py-1 text-xs font-semibold text-muted-foreground mt-2">Tier 3 Cities</div>
          {indianCities.filter(city => city.tier === "Tier 3").map((city) => (
            <SelectItem key={city.value} value={city.value}>
              {city.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default LocationSelector;