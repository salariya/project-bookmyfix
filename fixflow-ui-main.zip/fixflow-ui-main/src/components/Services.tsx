import { 
  Wrench, Zap, Sparkles, Shield, PaintBucket, Wind, 
  Key, Tv, Truck, TreePine, Droplets, Sun
} from "lucide-react";
import ServiceCard from "./ServiceCard";
import { useNavigate } from "react-router-dom";

const Services = () => {
  const navigate = useNavigate();
  
  const services = [
    {
      icon: Wrench,
      title: "Plumbing",
      description: "Tap/leaks, pipe bursts, and fixture repairs",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Zap,
      title: "Electrician",
      description: "Pick, point slot, place booking securely",
      color: "from-yellow-500 to-orange-500"
    },
    {
      icon: Sparkles,
      title: "Home Cleaning",
      description: "Our verified pro reaches your doorstep on time",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Sparkles,
      title: "Cleaning Services",
      description: "Deep cleaning, sofa/carpet cleaning, disinfection",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Shield,
      title: "Pest Control",
      description: "Termite, cockroach, rodent control services",
      color: "from-red-500 to-orange-600"
    },
    {
      icon: PaintBucket,
      title: "Painting & Renovation",
      description: "Wall painting, waterproofing, home remodeling",
      color: "from-indigo-500 to-purple-600"
    },
    {
      icon: Wind,
      title: "AC & HVAC Services",
      description: "Installation, gas refill, maintenance",
      color: "from-cyan-500 to-blue-500"
    },
    {
      icon: Key,
      title: "Locksmith Services",
      description: "Key duplication, lock repair, security systems",
      color: "from-amber-500 to-yellow-600"
    },
    {
      icon: Tv,
      title: "TV & Home Theater",
      description: "Mounting, wiring, smart home installation",
      color: "from-slate-500 to-gray-600"
    },
    {
      icon: Truck,
      title: "Moving & Shifting",
      description: "Packers & movers, furniture assembly",
      color: "from-emerald-500 to-green-600"
    },
    {
      icon: TreePine,
      title: "Gardening & Landscaping",
      description: "Lawn mowing, tree trimming services",
      color: "from-green-600 to-emerald-600"
    },
    {
      icon: Droplets,
      title: "Water Purifier & RO",
      description: "Installation, maintenance services",
      color: "from-blue-400 to-cyan-500"
    },
    {
      icon: Sun,
      title: "Solar Panel Services",
      description: "Home solar installation & repair solutions",
      color: "from-orange-400 to-yellow-500"
    }
  ];

  const handleServiceClick = (serviceTitle: string) => {
    navigate(`/pricing/${serviceTitle.toLowerCase().replace(/\s+/g, '-')}`);
  };

  return (
    <section id="services" className="py-16 md:py-24 bg-gradient-service">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional home services you can trust, available when you need them
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {services.map((service, index) => (
            <ServiceCard
              key={service.title}
              icon={service.icon}
              title={service.title}
              description={service.description}
              color={service.color}
              index={index}
              onClick={() => handleServiceClick(service.title)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;