import { Button } from "@/components/ui/button";
import { Smartphone, Download } from "lucide-react";

const AppDownload = () => {
  return (
    <section id="download" className="py-16 md:py-24 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="animate-fade-in-up">
            <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-8 shadow-glow animate-bounce-in">
              <Smartphone className="w-10 h-10 text-primary-foreground" />
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Download the BookMyFix App
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Coming soon on Android & iOS. Stay tuned for the ultimate home service experience!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-scale-in" style={{ animationDelay: "0.3s" }}>
            <Button 
              variant="app" 
              size="lg"
              className="group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                  <span className="text-white text-xs font-bold">G</span>
                </div>
                <div className="text-left">
                  <div className="text-xs text-muted-foreground">Get it on</div>
                  <div className="text-sm font-semibold">Google Play</div>
                </div>
              </div>
            </Button>

            <Button 
              variant="app" 
              size="lg"
              className="group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                  <span className="text-white text-xs">🍎</span>
                </div>
                <div className="text-left">
                  <div className="text-xs text-muted-foreground">Download on the</div>
                  <div className="text-sm font-semibold">App Store</div>
                </div>
              </div>
            </Button>
          </div>

          <div className="mt-12 animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
            <p className="text-sm text-muted-foreground mb-4">
              Want to be notified when we launch?
            </p>
            <Button variant="secondary" size="lg" className="group">
              <Download className="w-4 h-4 mr-2 group-hover:animate-bounce" />
              Notify Me
            </Button>
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-primary/5 rounded-full animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-24 h-24 bg-primary-glow/10 rounded-full animate-float" style={{ animationDelay: "2s" }}></div>
      </div>
    </section>
  );
};

export default AppDownload;