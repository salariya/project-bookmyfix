import { Search, Calendar, CheckCircle } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      icon: Search,
      title: "Choose Service",
      description: "Select the home service you need from our trusted professionals"
    },
    {
      number: "02",
      icon: Calendar,
      title: "Book & Schedule",
      description: "Pick your preferred time slot and schedule your appointment"
    },
    {
      number: "03",
      icon: CheckCircle,
      title: "Get it Fixed",
      description: "Sit back and relax while our experts take care of everything"
    }
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 bg-accent/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Getting your home fixed has never been easier. Just follow these simple steps
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  className="relative group animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.3}s` }}
                >
                  {/* Step number */}
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 md:left-0 md:transform-none">
                    <span className="inline-flex items-center justify-center w-12 h-12 bg-gradient-primary text-primary-foreground rounded-full text-lg font-bold shadow-glow">
                      {step.number}
                    </span>
                  </div>

                  {/* Connecting line (hidden on mobile) */}
                  {index < steps.length - 1 && (
                    <div className="hidden md:block absolute top-0 left-24 w-full h-0.5 bg-gradient-to-r from-primary to-primary-glow mt-6"></div>
                  )}

                  {/* Content card */}
                  <div className="bg-card rounded-2xl p-6 pt-12 md:pt-16 shadow-soft hover:shadow-medium transition-all duration-300 border border-border/50 group-hover:border-primary/30">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                        <Icon className="w-8 h-8 text-primary" />
                      </div>
                      
                      <h3 className="text-xl font-semibold text-foreground mb-3">
                        {step.title}
                      </h3>
                      
                      <p className="text-muted-foreground leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;