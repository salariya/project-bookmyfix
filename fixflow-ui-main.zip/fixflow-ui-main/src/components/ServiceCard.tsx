import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  index: number;
  onClick: () => void;
}

const ServiceCard = ({ icon: Icon, title, description, color, index, onClick }: ServiceCardProps) => {
  return (
    <div
      className="group bg-gradient-card rounded-3xl p-6 shadow-soft hover:shadow-hover transition-all duration-500 hover:-translate-y-3 border border-border/30 hover:border-primary/20 animate-fade-in-up cursor-pointer"
      style={{ animationDelay: `${index * 0.1}s` }}
      onClick={onClick}
    >
      <div className={`w-16 h-16 bg-gradient-to-r ${color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 mx-auto animate-bounce-in`}>
        <Icon className="w-8 h-8 text-white drop-shadow-sm" />
      </div>
      
      <h3 className="text-lg font-semibold text-foreground mb-2 text-center group-hover:text-primary transition-colors duration-300">
        {title}
      </h3>
      <p className="text-muted-foreground text-sm leading-relaxed text-center mb-4">
        {description}
      </p>

      <Button 
        variant="outline" 
        size="sm" 
        className="w-full group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all duration-300"
      >
        View Pricing
      </Button>

      {/* Hover effect decoration */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-primary-glow/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
    </div>
  );
};

export default ServiceCard;